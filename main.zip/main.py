import os
program1 = input()
site = "site"
if program1 == site:
    os.system("git clone https://github.com/FloppyDiskDriver/floppydiskdriver.github.io/ ")
else: 
   print ("package didn't found") 